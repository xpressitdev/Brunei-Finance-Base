// Shared state for debts (loans, financing, credit).
// The Debts page edits this list; the Budgets page reads from it and renders
// a card in the Bank column per debt. Adding here = new card on /budgets.

(function () {
  const TYPE_OPTIONS = ["Car", "House", "Personal", "Education", "Credit Card", "Other"];
  const ICON_BY_TYPE = {
    Car: "Activity", House: "Bank", Personal: "Wallet",
    Education: "Sparkles", "Credit Card": "Receipt", Other: "Bank",
  };

  // Seed = the 3 loans the prototype originally hardcoded.
  const SEED = [
    { id: "d1", name: "Toyota Hilux car loan", lender: "BIBD",    type: "Car",      balance: 18420,  rate: 4.2, monthlyPayment: 580.50, progress: 0.25 },
    { id: "d2", name: "House financing",       lender: "Baiduri", type: "House",    balance: 142000, rate: 3.8, monthlyPayment: 920.00, progress: 0.18 },
    { id: "d3", name: "Personal loan",         lender: "BIBD",    type: "Personal", balance: 4200,   rate: 6.0, monthlyPayment: 320.00, progress: 0.65 },
  ];

  const subscribers = new Set();
  let debts = SEED.slice();

  const notify = () => subscribers.forEach(fn => fn(debts));

  const store = {
    list: () => debts,
    typeOptions: () => TYPE_OPTIONS,
    iconFor: (type) => ICON_BY_TYPE[type] || "Bank",
    add: (loan) => {
      const id = "d" + Date.now().toString(36);
      debts = [...debts, { id, progress: 0, ...loan }];
      notify();
      return id;
    },
    update: (id, patch) => {
      debts = debts.map(d => d.id === id ? { ...d, ...patch } : d);
      notify();
    },
    remove: (id) => {
      debts = debts.filter(d => d.id !== id);
      notify();
    },
    subscribe: (fn) => {
      subscribers.add(fn);
      return () => subscribers.delete(fn);
    },
  };

  window.useDebts = function useDebts() {
    const [, setTick] = React.useState(0);
    React.useEffect(() => store.subscribe(() => setTick(t => t + 1)), []);
    return [store.list(), store];
  };

  window.debtsStore = store;
})();
