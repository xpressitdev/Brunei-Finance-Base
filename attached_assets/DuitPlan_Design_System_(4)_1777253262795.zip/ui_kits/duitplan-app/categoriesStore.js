// Shared state for expense categories (envelopes).
// The Expense Categories page edits this list; the Budgets page reads from it
// and renders an envelope per category. Adding here = new envelope on /budgets.

(function () {
  const ICON_OPTIONS = [
    "Bank", "Receipt", "Activity", "Lightbulb", "Trophy",
    "Star", "Sparkles", "Target", "Calendar", "Wallet", "Pie", "Bot"
  ];

  // Seed mirrors the original envelopes in Budgets.jsx so nothing visibly moves on first load.
  // `defaultBudget` is what the Budgets page uses as `target` and the initial `allocated`
  // for newly-added categories. `spent` is read elsewhere from transactions; here it's just demo.
  const SEED = [
    { id: "E1", name: "Rent — Beribi",   icon: "Bank",      fixed: true,  defaultBudget: 600, spent: 600 },
    { id: "E2", name: "Groceries",       icon: "Receipt",   fixed: false, defaultBudget: 600, spent: 240 },
    { id: "E3", name: "Eating out",      icon: "Receipt",   fixed: false, defaultBudget: 400, spent: 320 },
    { id: "E4", name: "Transport",       icon: "Activity",  fixed: false, defaultBudget: 500, spent: 580 },
    { id: "E5", name: "Utilities",       icon: "Lightbulb", fixed: true,  defaultBudget:  95, spent:  76 },
    { id: "E6", name: "Family support",  icon: "Trophy",    fixed: true,  defaultBudget: 350, spent: 350 },
  ];

  const subscribers = new Set();
  let categories = SEED.slice();

  const notify = () => subscribers.forEach(fn => fn(categories));

  const store = {
    list: () => categories,
    iconOptions: () => ICON_OPTIONS,
    add: (cat) => {
      const id = "E" + Date.now().toString(36);
      categories = [...categories, { id, spent: 0, ...cat }];
      notify();
      return id;
    },
    update: (id, patch) => {
      categories = categories.map(c => c.id === id ? { ...c, ...patch } : c);
      notify();
    },
    remove: (id) => {
      categories = categories.filter(c => c.id !== id);
      notify();
    },
    subscribe: (fn) => {
      subscribers.add(fn);
      return () => subscribers.delete(fn);
    },
  };

  // Hook for React components — re-renders on any change.
  window.useCategories = function useCategories() {
    const [, setTick] = React.useState(0);
    React.useEffect(() => store.subscribe(() => setTick(t => t + 1)), []);
    return [store.list(), store];
  };

  window.categoriesStore = store;
})();
