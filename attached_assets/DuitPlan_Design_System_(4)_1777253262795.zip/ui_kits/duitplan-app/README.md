# DuitPlan — Design Handoff for Replit

This document describes a **redesign** of the DuitPlan finance app, prepared in Claude Design as an interactive HTML prototype. It compares the current production code in `xpressitdev/Brunei-Finance-Base@main` (path: `artifacts/duitplan/`) against the new design and tells you what to change in the Replit codebase.

The prototype lives at `index.html` in this folder. Every screen referenced below is interactive — open it and click through to see the target behaviour.

---

## TL;DR — What's changing

The current production app is a fairly conventional list-and-form finance tracker. The redesign re-anchors the product around three ideas:

1. **A real "envelope" / YNAB-style budgets page** — drag-and-drop allocation from a visible "money bag", with three bucket types (envelopes, vaults, loans) and live feedback as you assign.
2. **A debts hub** with per-loan detail, repayment progress, payoff simulation (snowball/avalanche/custom), and consistent "minimum payment" indicators on every progress bar.
3. **A unified visual language** — same shadcn-based stack, but with a tighter card system, a single muted neutral palette, and consistent rules for "available / spent / over" colour states across every page.

The goal of this handoff is to migrate **screen by screen**, not to rewrite the app. Routes, data shapes, and API hooks (`useListBudgets`, `useUpsertBudget`, `useListCommitments`, `useListAccounts`, etc.) stay the same. Only the rendering and interaction layer changes.

---

## Stack assumptions (unchanged)

The redesign assumes the existing stack:

- React + Wouter routing (`client/src/App.tsx` → routes per page)
- TanStack Query + the `@workspace/api-client-react` hooks
- shadcn/ui + Tailwind, with the existing CSS variables (`--background`, `--foreground`, `--muted-foreground`, `--border`, etc.)
- `lucide-react` icons
- `date-fns` for month/year math

The prototype is built as inline-React JSX over Tailwind utility classes, so component bodies should port to `.tsx` with minimal change. Where the prototype uses `window.duitplanData` (a static fixture), the production version should swap in the equivalent TanStack Query hooks.

---

## File-by-file changes

### `src/pages/budgets.tsx` — **major rewrite**

This is the largest change. The current `budgets.tsx` is a single 34 KB file with three views (`plan` / `actual` / `annual`) rendered as stacked sections of cards and an annual table. Replace it with the new three-bucket model.

**What the new design does:**

- **Top bar** shows month navigator, "Reset" button, and a single subtitle: *"Changes save as you go."* Removes the old "Confirm allocation" / save-on-blur split.
- **Income block** — a "money bag" SVG whose coin-fill rises as `available / totalIncome`. To its right is a 6-amount drag-source grid (e.g. `BND 25 / 50 / 100 / 250 / 500 / 1000`). Drag a chip onto any envelope, vault, or loan card to allocate. Drag a chip back onto the bag to deallocate. Chips disable below the available amount, and dragstart is rejected when `available < amount`. Strip footer reads *"Nothing left to add. Drag back to the bag to free some up."* when empty.
- **Three bucket columns** rendered side by side:
  - **Envelopes** — variable monthly spend (groceries, transport, etc.). Card primary number = **remaining** (allocated − spent). Sub-text = *"BND X left of BND Y allocated."* Bar fills with spend; turns red when over.
  - **Vaults** — sinking funds and savings goals (Umrah, emergency fund). Primary number = **total saved + allocated this month**. Sub-text = *"of BND Y goal"*.
  - **Loans** — read-only summary tied to the Debts page. Primary number = **outstanding balance**. Bar is split at 50% by a tick labelled *"Minimum payment"*: rose fill grows from left up to the tick (this-month payment / minimum), and once you cross the minimum, a green segment extends rightward sized by the extra ratio. Right-aligned text shows lifetime % repaid. Footer line: *"Min BND X/mo · paying BND Y"*. When extra is allocated, a green hint appears: *"−N mo on tail"*. Each card has a *"Manage in Debts →"* button that routes to `/debts/:id`.
- **Fixed envelopes** (Rent, Utilities, Family support) accept drops just like flexible envelopes — the underlying `applyDrop` handler takes both `kind="envelope"` and `kind="envelopes"`.
- **Spending bars are read-only.** All "log a spend" affordances on envelope cards are removed. Envelope `actualAmount` is driven exclusively by transactions on the Transactions page.
- **Annual view** — keep the existing `AnnualView` table component as-is. It works well and the redesign doesn't touch it.

**Hooks / data:** same as today — `useListBudgets({ month })`, `useUpsertBudget`, `useListCategories`, `useListCommitments`, `useListAccounts`, `useGetProfile`. Loan rows on the budgets page should read from the same source as the Debts page (lifetime % repaid, minimum payment, current balance).

**Things to delete from the current file:**
- The "Forecast Plan / Actual vs Plan / Annual Report" three-button toggle. The redesign collapses Plan and Actual into a single live view (allocation + actual on the same bars).
- The "Ready to Assign" / "Available Pool" summary card at the bottom — replaced by the money-bag widget at the top.
- The YNAB-style 4-column grid (Category / Assigned / Activity / Available). The same information is now on the envelope card itself.

### `src/pages/debts.tsx` and `src/pages/debts/[id].tsx` — **moderate update**

The redesign keeps the routing (`/debts` index + `/debts/:id` detail) but introduces a consistent loan card pattern shared with the budgets page:

- Each loan card shows: name, lender, outstanding balance (large), lifetime % repaid, and the same **split bar with minimum-payment tick** described above.
- Detail page adds a **payoff simulator**: pick `snowball` / `avalanche` / `custom`, drag a slider for extra-monthly, see *"paid off N months earlier · BND X interest saved"*. The simulation logic is local to the page; no API change needed.
- Add an explicit `minPayment` field to the debt record if it isn't already there. The bar's tick position depends on it.

### `src/pages/transactions.tsx` — **light polish**

No structural change. Recommended tweaks:

- Group rows by day with a subtle date header.
- Add a category pill that matches the envelope colour from the Budgets page (use the same `categoryId → colour` map both pages reference).
- Make sure transaction creation/edit fires a refetch of `useListBudgets` so the envelope bars on `/budgets` update without a manual reload. (This is the key contract: **transactions are the only source of truth for `actualAmount`.**)

### `src/pages/dashboard.tsx` — **light update**

Keep the page; align it to the new visual language:

- KPI strip becomes 5 cards: *Monthly Salary*, *Commitments*, *Liabilities*, *This Month*, *Remaining* (hero). The `Remaining` card includes a mini breakdown: `−Commitments`, `−Spending`.
- Keep the *Hari Gaji* (payday) banner — it's a strong existing pattern. Wire it to `profile.payday` and dismiss-per-session.
- Fix the empty "Spending by Category" donut per ROADMAP §1.1.

### `src/pages/goals.tsx`, `src/pages/net-worth/`, `src/pages/accounts.tsx` — **visual alignment only**

No behaviour changes. Bring them onto the same card / type / spacing system:

- 1px borders, `rounded-xl`, `bg-card`, no drop shadows except on hover-elevated rows.
- Numeric values use the shared `fmtBND()` helper. Keep currency hard-coded as BND for now — multi-currency (ROADMAP §2.1) is out of scope for this redesign pass.
- Section headers use the small uppercase muted-foreground style already used on `budgets.tsx`.

### `src/components/layout/Sidebar.tsx` — **light update**

Keep the structure. Align active-state highlight (ROADMAP §1.4) and ensure these routes are present and ordered: Dashboard, Transactions, Budgets, Debts, Goals, Accounts, Net Worth, Insights, Settings.

The redesign collapses *Commitments* into the Budgets page (fixed envelopes section). Keep the `/commitments` route working as a redirect to `/budgets` for now so existing bookmarks don't break.

### `src/pages/insights.tsx`, `src/pages/upload.tsx`, `src/pages/onboarding.tsx`, `src/pages/agent.tsx`, `src/pages/achievements.tsx`, `src/pages/premium.tsx`, `src/pages/expenses/`, `src/pages/subscription/`, `src/pages/landing.tsx`, `src/pages/login.tsx`, `src/pages/register.tsx` — **no design change in this pass**

Out of scope for this iteration. They should inherit the shared visual tokens but their layouts are not redesigned here.

---

## Shared primitives — port these first

These are reused across every page. Build / update them before migrating individual screens:

1. **`<Card>`** — `rounded-xl border bg-card p-4` with optional hover-elevation. The current shadcn `card.tsx` is fine; just confirm padding and borders match the prototype.
2. **`<KpiCard>`** — label, big value, optional `delta` and `deltaLabel`, optional `footer` slot. Hero variant for the rightmost card.
3. **`<ProgressBar>` with optional minimum tick** — used on every loan card on both Budgets and Debts. Props: `value`, `max`, `min` (tick position as a fraction), `tone` (`default | over | success`).
4. **`<DragChip>` and `<DropTarget>`** — HTML5 drag-and-drop wrappers. Chips carry `{ amount }`; targets receive `(amount, kind, id)` and call `applyDrop`. The Budgets page is the only consumer today, but keep the components generic so they can be reused later (e.g. moving a transaction between categories).
5. **`fmtBND(n)`** — single formatter used everywhere. Lives in a shared `lib/fmt.ts`.
6. **`MoneyBag` SVG component** — coin-fill driven by a `0..1` ratio. Self-contained; copy directly from the prototype.

---

## Interaction & state contracts

These are the rules the prototype enforces. Mirror them in the production app:

- **Allocation persists immediately.** Every drop calls `useUpsertBudget` with the new `plannedAmount` and refetches. No "Save" button, no dirty state.
- **Drag from bag → bucket** increases that bucket's `plannedAmount` by the chip amount and decreases `available` by the same.
- **Drag from bucket → bag** does the reverse. Only the *most recently allocated* chip on that bucket can be removed (visualise it as a stack on the card; remove from the top).
- **Available = `salary − totalCommitments − sum(plannedAmount across all buckets)`**. Same formula the current `Budgets` page uses for `pool`. Keep it consistent.
- **Spent on an envelope** = sum of transactions in that category for the month. Read-only on the budgets page.
- **Loan progress** has two layers, never mixed:
  - *Lifetime* — `(originalPrincipal − currentBalance) / originalPrincipal`, shown as the right-aligned %.
  - *This month vs minimum* — drives the split bar.

---

## Visual tokens

The prototype is consistent with the existing CSS variables. No new tokens are needed:

- Greens: `text-emerald-700`, `bg-emerald-50`, `border-emerald-200` for income and "on track".
- Oranges: `text-orange-700`, `bg-orange-50`, `border-orange-200` for fixed commitments and minimum-payment ticks.
- Blues: `text-blue-700`, `bg-blue-50`, `border-blue-200` for variable budgets.
- Roses: `text-rose-600`, `bg-rose-50` for over-budget / debt principal.
- Muted neutrals: `bg-card`, `text-muted-foreground`, `border` for everything else.

Type scale follows the existing app — `text-3xl font-bold tracking-tight` for page H1, `text-sm font-semibold uppercase tracking-wide text-muted-foreground` for section labels, `font-mono` for numeric columns in tables.

---

## Recommended migration order

1. Land the shared primitives (`KpiCard`, `ProgressBar` with tick, `DragChip`/`DropTarget`, `MoneyBag`, `fmtBND`).
2. Rewrite `budgets.tsx` against those primitives. This is the biggest unlock and the most user-visible change.
3. Update `debts.tsx` + `debts/[id].tsx` to use the same loan-card and progress-bar pattern.
4. Wire transaction edits to refetch `useListBudgets` so spend bars stay live.
5. Polish dashboard (KPI strip + donut) and the remaining pages' visual alignment.
6. Roadmap items (multi-currency, i18n, Zakat, local bank parsers) — separate workstreams, not part of this redesign.

---

## What's *not* covered by this design

- Multi-currency (ROADMAP Phase 2.1) — prototype is BND-only.
- i18n (ROADMAP Phase 2.2) — all strings are English.
- Zakat calculator (ROADMAP Phase 3.1) — referenced in goals copy but no UI.
- Local bank parsers (ROADMAP Phase 3.2) — Upload page untouched.
- Subscription / payment / premium pages — untouched.
- Mobile layouts below 768 px — the prototype is desktop-first. Mobile responsive work is a follow-up pass.

---

## Files in this folder (for reference)

- `index.html` — entry point, loads React + Babel and the JSX modules below.
- `App.jsx` — top-level router (hash-based) and page switch.
- `Sidebar.jsx` — left nav.
- `Pages.jsx` — Dashboard, Transactions, Accounts.
- `Budgets.jsx`, `BudgetParts.jsx` — the redesigned Budgets page (collapsible bucket columns: Bank / Envelopes / Vault).
- `Debts.jsx` — debts hub + per-loan detail with payoff simulator.
- `ExpenseCategories.jsx` — manage envelope categories; edits flow through to the Budgets envelopes column via `categoriesStore`.
- `Goals.jsx` — savings goals with `goalsStore` for create/edit/delete.
- `NetWorth.jsx` — net-worth page with the Assets vs Liabilities proportion bar (replaces the older balance-scale metaphor).
- `Components.jsx`, `primitives.jsx`, `icons.jsx` — shared components, buttons, inputs, icons.
- `categoriesStore.js`, `debtsStore.js`, `goalsStore.js` — small in-memory stores with `subscribe / get / mutate` APIs that mirror the shape the production TanStack Query hooks return.
- `data.js` — static fixture data (`window.duitplanData`). In production this is replaced by the existing TanStack Query hooks.
- `tweaks-panel.jsx` — design-time tweaks panel (toolbar toggle in the preview); not for production.

---

## Updates since the first handoff pass

These were added after the README was first written:

- **Expense Categories page** — a dedicated `/categories` route (or sidebar entry) for adding / editing / archiving envelope categories. Adding a category here makes it appear immediately as an envelope on the Budgets page with `defaultBudget` as its starting `plannedAmount`. Wire to the existing `useListCategories` / `useUpsertCategory` hooks; the prototype uses `categoriesStore.js` to model the same flow.
- **Bucket columns are collapsible** — each of the three columns on Budgets (Bank, Envelopes, Vault) has a header that doubles as a collapse toggle (chevron + count badge). Collapsed state persists per-column via `localStorage` under `duitplan-budget-col-collapsed:<title>`. When collapsed, the subtitle reads *"BND X allocated · click to expand"*.
- **Net Worth — Assets vs Liabilities panel** — replaces the see-saw scale with a cleaner proportion bar: two stat cards (Assets / Liabilities) with breakdown sublines, a single split bar showing share of total with a break-even tick at 50%, then three health stats (Debt-to-asset, Liquid runway, Equity share) below.
- **Goals page** — full CRUD on savings goals. Each goal card shows progress, monthly contribution, target date, and an "Add to vault" affordance that links back to the Budgets vault column.
- **Debts payoff simulator** — pick `snowball` / `avalanche` / `custom`, drag a slider for extra-monthly. Same minimum-payment-tick progress bar pattern as the Budgets loan cards.

Open `index.html` and click the sidebar to walk through every screen. The Budgets page is the centrepiece — start there.
