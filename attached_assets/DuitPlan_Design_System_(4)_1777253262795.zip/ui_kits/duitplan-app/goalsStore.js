// Shared state for savings goals (vaults).
// The Goals page edits this list; the Budgets page reads from it and renders
// a card in the Vault column per goal. Adding here = new card on /budgets.

(function () {
  const ICON_OPTIONS = [
    "Star", "Trophy", "Sparkles", "Target", "Wallet", "Bank", "Calendar", "Lightbulb"
  ];

  // Seed = the 3 goals the prototype originally hardcoded.
  const SEED = [
    { id: "g1", name: "Umrah 2027",      icon: "Star",     target: 12000, saved: 3450, deadline: "2027-09", monthlyContribution: 200 },
    { id: "g2", name: "Emergency fund",  icon: "Trophy",   target:  9000, saved: 6200, deadline: "2026-12", monthlyContribution: 100 },
    { id: "g3", name: "Kids' education", icon: "Sparkles", target: 25000, saved: 4100, deadline: "2030-01", monthlyContribution:  50 },
  ];

  const subscribers = new Set();
  let goals = SEED.slice();

  const notify = () => subscribers.forEach(fn => fn(goals));

  const store = {
    list: () => goals,
    iconOptions: () => ICON_OPTIONS,
    add: (goal) => {
      const id = "g" + Date.now().toString(36);
      goals = [...goals, { id, saved: 0, ...goal }];
      notify();
      return id;
    },
    update: (id, patch) => {
      goals = goals.map(g => g.id === id ? { ...g, ...patch } : g);
      notify();
    },
    remove: (id) => {
      goals = goals.filter(g => g.id !== id);
      notify();
    },
    subscribe: (fn) => {
      subscribers.add(fn);
      return () => subscribers.delete(fn);
    },
  };

  window.useGoals = function useGoals() {
    const [, setTick] = React.useState(0);
    React.useEffect(() => store.subscribe(() => setTick(t => t + 1)), []);
    return [store.list(), store];
  };

  window.goalsStore = store;
})();
