// Goals — manage the list of long-term savings goals (vaults) used on the Budgets page.
// Adding/editing here flows directly into Budgets via window.goalsStore.

const Goals = ({ onNav }) => {
  const I = window.Icons;
  const [goals, store] = window.useGoals();
  const blank = { name: "", icon: "Star", target: "", deadline: "", monthlyContribution: "" };
  const [draft, setDraft] = React.useState(blank);
  const [editingId, setEditingId] = React.useState(null);
  const [editDraft, setEditDraft] = React.useState({});

  const totalTarget = goals.reduce((s, g) => s + Number(g.target || 0), 0);
  const totalSaved  = goals.reduce((s, g) => s + Number(g.saved || 0), 0);
  const totalMonthly = goals.reduce((s, g) => s + Number(g.monthlyContribution || 0), 0);
  const overallPct = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0;

  const IconList = store.iconOptions();
  const Glyph = (name) => window.Icons[name] || window.Icons.Star;

  // Estimate months remaining at current contribution rate.
  const monthsLeft = (g) => {
    const remaining = Math.max(0, g.target - g.saved);
    if (!g.monthlyContribution || g.monthlyContribution <= 0) return null;
    return Math.ceil(remaining / g.monthlyContribution);
  };

  const submit = (e) => {
    e.preventDefault();
    const target = Number(draft.target);
    const monthlyContribution = Number(draft.monthlyContribution || 0);
    if (!draft.name.trim()) return;
    if (!Number.isFinite(target) || target <= 0) return;
    if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0) return;
    store.add({
      name: draft.name.trim(), icon: draft.icon, target,
      deadline: draft.deadline.trim(), monthlyContribution,
    });
    setDraft(blank);
  };

  const startEdit = (g) => {
    setEditingId(g.id);
    setEditDraft({
      name: g.name, icon: g.icon || "Star", target: String(g.target),
      deadline: g.deadline || "", monthlyContribution: String(g.monthlyContribution || 0),
    });
  };
  const saveEdit = () => {
    const target = Number(editDraft.target);
    const monthlyContribution = Number(editDraft.monthlyContribution || 0);
    if (!editDraft.name.trim()) return;
    if (!Number.isFinite(target) || target <= 0) return;
    if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0) return;
    store.update(editingId, {
      name: editDraft.name.trim(), icon: editDraft.icon, target,
      deadline: editDraft.deadline.trim(), monthlyContribution,
    });
    setEditingId(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Topbar
        title="Goals"
        subtitle="Add or edit savings goals. Each one becomes a Vault card on the Budgets page that you fund every month."
        actions={<Button variant="outline" size="sm" onClick={() => onNav && onNav("budgets")}>
          <I.Pie width="14" height="14"/>View on Budgets
        </Button>}
      />

      {/* Summary strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Goals</div>
          <div className="text-2xl font-bold tracking-tight mt-1">{goals.length}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">Long-term savings vaults</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Saved so far</div>
          <div className="text-2xl font-bold tabular-nums tracking-tight mt-1 text-[hsl(var(--primary))]">{window.fmtBND(totalSaved)}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1 tabular-nums">{Math.round(overallPct)}% of {window.fmtBND(totalTarget)}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Monthly contribution</div>
          <div className="text-2xl font-bold tabular-nums tracking-tight mt-1">{window.fmtBND(totalMonthly)}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">Across all goals</div>
        </Card>
        <Card className="p-4 bg-[hsl(var(--accent))]/40 border-dashed">
          <div className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-md bg-white border border-[hsl(var(--border))] flex items-center justify-center text-[hsl(var(--primary))] shrink-0">
              <I.Lightbulb width="14" height="14"/>
            </div>
            <div className="flex-1">
              <div className="text-[12px] font-semibold">How this connects to Budgets</div>
              <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5 leading-relaxed">
                Each goal becomes a card in the <span className="font-semibold">Vault</span> column. Pulling money out is friction-locked.
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Add new */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-md bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))] flex items-center justify-center">
            <I.Plus width="14" height="14"/>
          </div>
          <h2 className="text-base font-semibold tracking-tight">Add a goal</h2>
        </div>
        <form onSubmit={submit} className="grid md:grid-cols-[1.4fr_140px_140px_140px_140px_auto] gap-2 items-end">
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Name</label>
            <input
              type="text" placeholder="e.g. Umrah 2027, Wedding fund"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              className="mt-1 w-full h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Icon</label>
            <select
              value={draft.icon}
              onChange={(e) => setDraft({ ...draft, icon: e.target.value })}
              className="mt-1 w-full h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]">
              {IconList.map(name => <option key={name} value={name}>{name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Target</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={draft.target}
                onChange={(e) => setDraft({ ...draft, target: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Deadline</label>
            <input
              type="month"
              value={draft.deadline}
              onChange={(e) => setDraft({ ...draft, deadline: e.target.value })}
              className="mt-1 w-full h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Monthly /mo</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={draft.monthlyContribution}
                onChange={(e) => setDraft({ ...draft, monthlyContribution: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
            </div>
          </div>
          <Button type="submit" size="default">
            <I.Plus width="14" height="14"/>Add
          </Button>
        </form>
      </Card>

      {/* List */}
      <Card className="p-0 overflow-hidden">
        <div className="px-5 py-3 flex items-center justify-between border-b border-[hsl(var(--border))]">
          <div className="text-sm font-semibold">Your goals</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))]">Tap a row to edit</div>
        </div>
        <div className="divide-y divide-[hsl(var(--border))]">
          {goals.length === 0 && (
            <div className="px-5 py-10 text-center text-sm text-[hsl(var(--muted-foreground))]">
              No goals yet. Add one above to start saving toward something.
            </div>
          )}
          {goals.map(g => {
            const Ic = Glyph(g.icon);
            const isEditing = editingId === g.id;
            const pct = g.target > 0 ? Math.min(100, (g.saved / g.target) * 100) : 0;
            const left = monthsLeft(g);
            return (
              <div key={g.id} className="px-5 py-4 hover:bg-[hsl(var(--accent))]/30 transition-colors">
                {isEditing ? (
                  <div className="grid md:grid-cols-[40px_1.4fr_140px_140px_140px_140px_auto_auto] gap-2 items-center">
                    <div className="w-9 h-9 rounded-md bg-amber-50 flex items-center justify-center text-amber-700">
                      <Ic width="16" height="16"/>
                    </div>
                    <input
                      type="text" value={editDraft.name}
                      onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })}
                      className="h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
                    <select
                      value={editDraft.icon}
                      onChange={(e) => setEditDraft({ ...editDraft, icon: e.target.value })}
                      className="h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none">
                      {IconList.map(n => <option key={n} value={n}>{n}</option>)}
                    </select>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
                      <input type="number" min="0" step="0.01" value={editDraft.target}
                        onChange={(e) => setEditDraft({ ...editDraft, target: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                    </div>
                    <input
                      type="month" value={editDraft.deadline}
                      onChange={(e) => setEditDraft({ ...editDraft, deadline: e.target.value })}
                      className="h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
                      <input type="number" min="0" step="0.01" value={editDraft.monthlyContribution}
                        onChange={(e) => setEditDraft({ ...editDraft, monthlyContribution: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                    </div>
                    <Button size="sm" onClick={saveEdit}><I.Check width="14" height="14"/>Save</Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-[40px_1fr_auto_auto_auto] gap-3 items-center">
                    <div className="w-9 h-9 rounded-md bg-amber-50 text-amber-700 flex items-center justify-center">
                      <Ic width="16" height="16"/>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-semibold truncate">{g.name}</div>
                        {g.deadline && <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">By {g.deadline}</span>}
                      </div>
                      <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5 tabular-nums">
                        {window.fmtBND(g.saved)} of {window.fmtBND(g.target)} saved
                        {left !== null && left > 0 && <span> · ~{left} mo at {window.fmtBND(g.monthlyContribution)}/mo</span>}
                      </div>
                      <div className="mt-2 h-1.5 rounded-full bg-[hsl(var(--muted))] overflow-hidden max-w-md">
                        <div className="h-full rounded-full bg-amber-500" style={{ width: `${pct}%` }}/>
                      </div>
                      <div className="text-[10px] text-[hsl(var(--muted-foreground))] mt-1 tabular-nums">{Math.round(pct)}% of goal</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Monthly</div>
                      <div className="text-sm font-bold tabular-nums">{window.fmtBND(g.monthlyContribution || 0)}</div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => startEdit(g)}>
                      <I.Edit width="13" height="13"/>Edit
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => {
                      if (confirm(`Delete "${g.name}"? Its vault will also be removed from Budgets.`)) {
                        store.remove(g.id);
                      }
                    }} className="text-rose-600 hover:bg-rose-50">
                      <I.Trash width="13" height="13"/>
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};

window.Goals = Goals;
