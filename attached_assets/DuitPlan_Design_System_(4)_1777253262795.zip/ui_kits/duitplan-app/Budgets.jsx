// Budgets page — drag-and-drop allocation of Available income into envelopes.
// Three columns from the founder sketch: Bank (loans) · Envelopes (expenses) · Vault (goals).
// All buckets are user-controlled. Overspend turns the envelope red.
// Vault uses a friction-lock confirm modal before money can be pulled back.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "metaphor": "drag",
  "envelopeStyle": "illustration",
  "animationLevel": "calm",
  "showLoans": true
}/*EDITMODE-END*/;

// Allocation overrides keyed by id (categories/debts/goals). New items default to 0
// so adding a category, loan, or goal never silently consumes the available pool.
// SEED_* pre-funds the demo items so the prototype loads with a realistic state.
const SEED_ENVELOPE_ALLOC = {
  E1: 600, E2: 400, E3: 300, E4: 250, E5: 95, E6: 350,
};
const SEED_LOAN_ALLOC = {
  d1: 580, d2: 920, d3: 320,
};
const SEED_VAULT_ALLOC = {
  g1: 200, g2: 100, g3: 50,
};

// Generic factory: pulls items from a store, derives Budget-shaped buckets, and
// keeps a per-id allocation override map so allocations survive list edits.
const makeBucketHook = (useStore, seed, mapItem) => () => {
  const [items] = useStore();
  const [allocOverride, setAllocOverride] = React.useState(seed);

  const buckets = React.useMemo(() => items.map(item => ({
    ...mapItem(item),
    id: item.id,
    allocated: allocOverride[item.id] !== undefined ? allocOverride[item.id] : 0,
  })), [items, allocOverride]);

  const setAllocFor = (id, val) => setAllocOverride(prev => ({ ...prev, [id]: val }));
  const resetAllocations = () => setAllocOverride(seed);

  return [buckets, setAllocFor, resetAllocations];
};

const useEnvelopesFromStore = makeBucketHook(
  () => window.useCategories(),
  SEED_ENVELOPE_ALLOC,
  (c) => ({
    name: c.name, target: c.defaultBudget, spent: c.spent || 0,
    fixed: c.fixed, illo: "payslip", icon: c.icon,
  })
);

const useLoansFromStore = makeBucketHook(
  () => window.useDebts(),
  SEED_LOAN_ALLOC,
  (d) => ({
    name: d.name, target: d.monthlyPayment, spent: d.monthlyPayment,
    balance: d.balance, lender: d.lender,
    repaymentProgress: d.progress || 0,
    illo: "bank", icon: window.debtsStore.iconFor(d.type), auto: true,
    debtId: d.id,
  })
);

const useVaultsFromStore = makeBucketHook(
  () => window.useGoals(),
  SEED_VAULT_ALLOC,
  (g) => ({
    name: g.name, target: g.target, saved: g.saved,
    deadline: g.deadline,
    illo: "vault", icon: g.icon || "Star",
  })
);

const totalIncome = 4250;

const Budgets = ({ onNav }) => {
  const I = window.Icons;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [envelopes, setEnvAlloc, resetEnvAlloc] = useEnvelopesFromStore();
  const [loans,    setLoanAlloc,  resetLoanAlloc]  = useLoansFromStore();
  const [vaults,   setVaultAlloc, resetVaultAlloc] = useVaultsFromStore();
  const [dragging, setDragging] = React.useState(null); // {amount, fromId?}
  const [overTarget, setOverTarget] = React.useState(null);
  const [vaultUnlock, setVaultUnlock] = React.useState(null); // vault id pending unlock
  const [unlockReason, setUnlockReason] = React.useState("");
  const [pulse, setPulse] = React.useState(null); // bucket id flashing on drop
  const [customAmt, setCustomAmt] = React.useState(""); // free-form chip amount

  const allocLoans = loans.reduce((s, b) => s + b.allocated, 0);
  const allocEnv   = envelopes.reduce((s, b) => s + b.allocated, 0);
  const allocVault = vaults.reduce((s, b) => s + b.allocated, 0);
  const allocated  = allocLoans + allocEnv + allocVault;
  const available  = totalIncome - allocated;
  const pctAlloc   = Math.min(100, (allocated / totalIncome) * 100);

  const visibleLoans = t.showLoans ? loans : [];

  const flashPulse = (id) => {
    setPulse(id);
    setTimeout(() => setPulse(null), t.animationLevel === "satisfying" ? 700 : 350);
  };

  // --- drag mechanics ---
  const startDrag = (amount, fromKind, fromId) => (e) => {
    // Block adding from the bag when there's no available money.
    if (!fromId && available < amount) { e.preventDefault?.(); return; }
    setDragging({ amount, fromKind, fromId });
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", String(amount)); } catch {}
  };
  const onDragOver = (kind, id) => (e) => { e.preventDefault(); setOverTarget(`${kind}:${id}`); };
  const onDragLeave = () => setOverTarget(null);

  // Helper: change a bucket's allocation. All three columns now route through their
  // own store-backed hooks (categories / debts / goals).
  const adjustAlloc = (kind, id, delta) => {
    if (kind === "envelope" || kind === "envelopes") {
      const cur = envelopes.find(b => b.id === id);
      if (!cur) return;
      setEnvAlloc(id, Math.max(0, cur.allocated + delta));
    } else if (kind === "loans" || kind === "loan") {
      const cur = loans.find(b => b.id === id);
      if (!cur) return;
      setLoanAlloc(id, Math.max(0, cur.allocated + delta));
    } else if (kind === "vault" || kind === "vaults") {
      const cur = vaults.find(b => b.id === id);
      if (!cur) return;
      setVaultAlloc(id, Math.max(0, cur.allocated + delta));
    }
  };

  // Drop chip back into the bag = deallocate the amount from its source bucket.
  const onDropToBag = (e) => {
    e.preventDefault();
    setOverTarget(null);
    if (!dragging || !dragging.fromId) { setDragging(null); return; } // chips from the bag itself can't drop back
    const { amount, fromKind, fromId } = dragging;
    if (fromKind === "vault") {
      // Pulling from a vault still requires the friction lock.
      setVaultUnlock({ fromId, toKind: "bag", toId: "bag", amount });
    } else {
      adjustAlloc(fromKind, fromId, -amount);
    }
    setDragging(null);
  };

  const applyDrop = (kind, id, amount) => {
    adjustAlloc(kind, id, amount);
    flashPulse(id);
  };

  const onDrop = (kind, id) => (e) => {
    e.preventDefault();
    if (!dragging) return;
    const amt = dragging.amount;
    if (dragging.fromId && dragging.fromKind === "vault" && dragging.fromId !== id) {
      // Trying to MOVE money out of a vault — friction lock
      setVaultUnlock({ fromId: dragging.fromId, toKind: kind, toId: id, amount: amt });
    } else if (dragging.fromId) {
      // Moving from one envelope/loan to another
      adjustAlloc(dragging.fromKind, dragging.fromId, -amt);
      applyDrop(kind, id, amt);
    } else {
      applyDrop(kind, id, amt);
    }
    setDragging(null); setOverTarget(null);
  };

  const confirmVaultUnlock = () => {
    if (!vaultUnlock || !unlockReason.trim()) return;
    adjustAlloc("vault", vaultUnlock.fromId, -vaultUnlock.amount);
    if (vaultUnlock.toKind !== "bag") {
      adjustAlloc(vaultUnlock.toKind, vaultUnlock.toId, vaultUnlock.amount);
      flashPulse(vaultUnlock.toId);
    }
    setVaultUnlock(null); setUnlockReason("");
  };

  const reset = () => { resetEnvAlloc(); resetLoanAlloc(); resetVaultAlloc(); };

  // Logging a transaction increments `spent` for that envelope, which drains its bar.
  // (In the real app this is driven by import/manual entry on the Transactions page.)
  const logSpend = (id, amount) => {
    // Spent is owned by the categories store now; bump it there.
    const cur = window.categoriesStore.list().find(c => c.id === id);
    if (cur) window.categoriesStore.update(id, { spent: (cur.spent || 0) + amount });
    flashPulse(id);
  };

  const motionMS = t.animationLevel === "satisfying" ? 500 : t.animationLevel === "none" ? 0 : 250;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Topbar
        title="Budgets"
        subtitle="Allocate your gaji. Drag from the bag into Bank, Envelopes, or Vault — changes save as you go."
        actions={<>
          <Button variant="outline" size="sm" onClick={reset}>Reset</Button>
        </>}
      />

      {/* AVAILABLE STRIP — with interactive money bag */}
      <Card tinted={available >= 0} className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex-1">
            <Eyebrow className="text-[hsl(var(--primary))]">Available to allocate</Eyebrow>
            <div className="flex items-baseline gap-3 mt-1">
              <div className={`text-4xl font-bold tabular-nums ${available <= 0 ? "text-rose-600" : "text-[hsl(var(--primary))]"}`}>
                {available < 0 ? "−" : ""}{window.fmtBND(Math.abs(available))}
              </div>
              <div className="text-sm text-[hsl(var(--muted-foreground))]">of {window.fmtBND(totalIncome)} April gaji</div>
            </div>
            <div className="mt-3 h-2 rounded-full bg-[hsl(var(--muted))] overflow-hidden w-full lg:w-96">
              <div className={`h-full rounded-full ${available < 0 ? "bg-rose-500" : "bg-[hsl(var(--primary))]"}`}
                   style={{ width: `${pctAlloc}%`, transition: `width ${motionMS}ms cubic-bezier(.2,.8,.2,1)` }}/>
            </div>
            <div className="text-xs text-[hsl(var(--muted-foreground))] mt-1.5 tabular-nums">
              {window.fmtBND(allocated)} allocated · {Math.round(pctAlloc)}%
              {available <= 0 && <span className="ml-2 text-rose-600 font-semibold">— nothing left to add. Drag back to the bag to free some up.</span>}
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* The bag itself — fills/empties with available; accepts dropped chips to deallocate. */}
            <MoneyBag available={available} total={totalIncome}
              isOver={overTarget === "bag:bag"} animationLevel={t.animationLevel} motionMS={motionMS}
              onDragOver={(e) => { e.preventDefault(); setOverTarget("bag:bag"); }}
              onDragLeave={onDragLeave}
              onDropBack={onDropToBag}/>

            {/* Money chips — drag amounts OUT of the bag. Disabled when bag is empty. */}
            <div className="flex flex-col gap-2">
              <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Drag from bag</div>
              <div className="grid grid-cols-3 gap-1.5 w-44">
                {[10, 25, 50, 100, 250, 500].map(amt => (
                  <MoneyChip key={amt} amount={amt} disabled={available < amt}
                    onDragStart={startDrag(amt)} onDragEnd={() => setDragging(null)}
                    metaphor={t.metaphor} animationLevel={t.animationLevel}/>
                ))}
                {/* Custom amount — type any number, then drag this chip onto a bucket. */}
                <CustomMoneyChip
                  available={available}
                  value={customAmt}
                  onChange={setCustomAmt}
                  onDragStart={(amt) => startDrag(amt)}
                  onDragEnd={() => { setDragging(null); setCustomAmt(""); }}
                  animationLevel={t.animationLevel}/>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* THREE COLUMNS */}
      <div className="grid lg:grid-cols-3 gap-5">

        {/* BANK / LOANS */}
        <BucketColumn title="Bank" subtitle="Loan repayments — auto on Hari Gaji"
                      illo="bank" iconBg="bg-rose-50" iconColor="text-rose-600"
                      count={visibleLoans.length}
                      total={visibleLoans.reduce((s,b)=>s+(b.allocated||0),0)}>
          {visibleLoans.map(b => (
            <Envelope key={b.id} bucket={b} kind="loans"
              isOver={overTarget === `loans:${b.id}`} pulse={pulse === b.id}
              metaphor={t.metaphor} envelopeStyle={t.envelopeStyle} motionMS={motionMS}
              onDragOver={onDragOver("loans", b.id)} onDragLeave={onDragLeave}
              onDrop={onDrop("loans", b.id)}
              onDragChip={(amt) => startDrag(amt, "loans", b.id)}
              onSlider={(v) => setLoanAlloc(b.id, v)}
              onInput={(v) => setLoanAlloc(b.id, v)}
              onGotoDebts={() => onNav && onNav("debts")}
              available={available}/>
          ))}
          {!t.showLoans && <EmptyHint>Loans hidden — toggle in Tweaks.</EmptyHint>}
        </BucketColumn>

        {/* ENVELOPES */}
        <BucketColumn title="Envelopes" subtitle="Spending categories — drained as you spend"
                      illo="payslip" iconBg="bg-[hsl(162_70%_35%/.08)]" iconColor="text-[hsl(var(--primary))]"
                      count={envelopes.length}
                      total={envelopes.reduce((s,b)=>s+(b.allocated||0),0)}>
          {envelopes.map(b => (
            <Envelope key={b.id} bucket={b} kind="envelope"
              isOver={overTarget === `envelope:${b.id}`} pulse={pulse === b.id}
              metaphor={t.metaphor} envelopeStyle={t.envelopeStyle} motionMS={motionMS}
              onDragOver={onDragOver("envelope", b.id)} onDragLeave={onDragLeave}
              onDrop={onDrop("envelope", b.id)}
              onDragChip={(amt) => startDrag(amt, "envelope", b.id)}
              onSlider={(v) => setEnvAlloc(b.id, v)}
              onInput={(v) => setEnvAlloc(b.id, v)}
              onLogSpend={(amt) => logSpend(b.id, amt)}
              available={available}/>
          ))}
          {envelopes.length === 0 && (
            <EmptyHint>No categories yet. Add some on the <button onClick={() => onNav && onNav("categories")} className="underline font-semibold text-[hsl(var(--primary))]">Expense Categories</button> tab.</EmptyHint>
          )}
        </BucketColumn>

        {/* VAULT / GOALS */}
        <BucketColumn title="Vault" subtitle="Long-term goals — friction-locked"
                      illo="vault" iconBg="bg-amber-50" iconColor="text-amber-700"
                      count={vaults.length}
                      total={vaults.reduce((s,b)=>s+(b.allocated||0),0)}>
          {vaults.map(b => (
            <Envelope key={b.id} bucket={b} kind="vault" isVault
              isOver={overTarget === `vault:${b.id}`} pulse={pulse === b.id}
              metaphor={t.metaphor} envelopeStyle={t.envelopeStyle} motionMS={motionMS}
              onDragOver={onDragOver("vault", b.id)} onDragLeave={onDragLeave}
              onDrop={onDrop("vault", b.id)}
              onDragChip={(amt) => startDrag(amt, "vault", b.id)}
              onSlider={(v) => setVaultAlloc(b.id, v)}
              onInput={(v) => setVaultAlloc(b.id, v)}
              available={available}/>
          ))}
        </BucketColumn>
      </div>

      {/* VAULT UNLOCK MODAL */}
      {vaultUnlock && (
        <Modal onClose={() => { setVaultUnlock(null); setUnlockReason(""); }}>
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center"><I.Lightbulb width="20" height="20"/></div>
            <div>
              <div className="text-lg font-semibold">Take money out of your vault?</div>
              <div className="text-sm text-[hsl(var(--muted-foreground))] mt-1">
                Vaults are for long-term goals. Pulling {window.fmtBND(vaultUnlock.amount)} out will set you back. Tell us why — it'll be logged.
              </div>
            </div>
          </div>
          <textarea value={unlockReason} onChange={e => setUnlockReason(e.target.value)} rows={3}
            placeholder="e.g. Car broke down, need to cover repair this month."
            className="w-full p-3 rounded-md border border-[hsl(var(--input))] text-sm outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"/>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="ghost" size="sm" onClick={() => { setVaultUnlock(null); setUnlockReason(""); }}>Cancel</Button>
            <Button size="sm" onClick={confirmVaultUnlock}
              className={!unlockReason.trim() ? "opacity-50 pointer-events-none" : ""}>
              Confirm — take it out
            </Button>
          </div>
        </Modal>
      )}

      {/* TWEAKS */}
      <TweaksPanel>
        <TweakSection label="Allocation"/>
        <TweakRadio label="Metaphor" value={t.metaphor} options={["drag", "slider", "input"]} onChange={v => setTweak("metaphor", v)}/>
        <TweakToggle label="Show loans column" value={t.showLoans} onChange={v => setTweak("showLoans", v)}/>
        <TweakSection label="Visual"/>
        <TweakRadio label="Envelope style" value={t.envelopeStyle} options={["illustration", "flat", "glyph"]} onChange={v => setTweak("envelopeStyle", v)}/>
        <TweakRadio label="Animation" value={t.animationLevel} options={["none", "calm", "satisfying"]} onChange={v => setTweak("animationLevel", v)}/>
      </TweaksPanel>
    </div>
  );
};

window.Budgets = Budgets;
