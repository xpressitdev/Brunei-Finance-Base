// Debts — manage the list of loans/financing/credit used on the Budgets page.
// Adding/editing here flows directly into Budgets via window.debtsStore.

// What-if extra-payment simulation: amortization with optional extra principal.
// Returns { months, totalInterest, schedule[{m, balance}] }.
const simulatePayoff = (balance, annualRatePct, monthlyPayment, extraMonthly = 0) => {
  const r = (annualRatePct / 100) / 12;
  const total = (monthlyPayment || 0) + (extraMonthly || 0);
  const schedule = [{ m: 0, balance }];
  let bal = balance;
  let interestPaid = 0;
  let m = 0;
  const MAX = 12 * 60; // hard stop at 60 years
  while (bal > 0.01 && m < MAX) {
    m += 1;
    const interest = bal * r;
    let principal = total - interest;
    // If the payment can't even cover interest, the loan never pays down — bail with sentinel.
    if (principal <= 0) { return { months: Infinity, totalInterest: Infinity, schedule }; }
    if (principal > bal) principal = bal;
    bal = bal - principal;
    interestPaid += interest;
    schedule.push({ m, balance: Math.max(0, bal) });
  }
  return { months: m, totalInterest: interestPaid, schedule };
};

// Tiny inline SVG line chart for two payoff curves.
const PayoffChart = ({ baseline, withExtra, height = 110 }) => {
  const W = 480, H = height, P = 8;
  const allMonths = Math.max(baseline.months, withExtra.months);
  if (!Number.isFinite(allMonths) || allMonths <= 0) {
    return <div className="text-[11px] text-[hsl(var(--muted-foreground))] py-4">Not enough data to simulate.</div>;
  }
  const maxBal = Math.max(
    ...baseline.schedule.map(p => p.balance),
    ...withExtra.schedule.map(p => p.balance)
  );
  const x = (m) => P + (m / allMonths) * (W - P * 2);
  const y = (bal) => P + (1 - bal / maxBal) * (H - P * 2);
  const path = (sched) => sched.map((p, i) => `${i === 0 ? "M" : "L"}${x(p.m).toFixed(1)},${y(p.balance).toFixed(1)}`).join(" ");
  const area = (sched) => path(sched) + ` L${x(sched[sched.length - 1].m).toFixed(1)},${y(0).toFixed(1)} L${x(0).toFixed(1)},${y(0).toFixed(1)} Z`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full h-[110px]">
      <defs>
        <linearGradient id="extraFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="hsl(162 70% 35%)" stopOpacity="0.18"/>
          <stop offset="100%" stopColor="hsl(162 70% 35%)" stopOpacity="0"/>
        </linearGradient>
      </defs>
      {/* Baseline (dashed rose) */}
      <path d={path(baseline.schedule)} fill="none" stroke="hsl(0 70% 55%)" strokeWidth="1.6" strokeDasharray="4 3" opacity="0.7"/>
      {/* With extra (solid green + soft fill) */}
      <path d={area(withExtra.schedule)} fill="url(#extraFill)" stroke="none"/>
      <path d={path(withExtra.schedule)} fill="none" stroke="hsl(162 70% 35%)" strokeWidth="2"/>
      {/* Baseline X-axis */}
      <line x1={P} y1={H - P} x2={W - P} y2={H - P} stroke="hsl(220 13% 88%)" strokeWidth="1"/>
    </svg>
  );
};

const LoanSimulation = ({ loan }) => {
  const I = window.Icons;
  const [extra, setExtra] = React.useState(0);

  const baseline = React.useMemo(
    () => simulatePayoff(loan.balance, loan.rate, loan.monthlyPayment, 0),
    [loan.balance, loan.rate, loan.monthlyPayment]
  );
  const withExtra = React.useMemo(
    () => simulatePayoff(loan.balance, loan.rate, loan.monthlyPayment, extra),
    [loan.balance, loan.rate, loan.monthlyPayment, extra]
  );

  const monthsSaved = Number.isFinite(baseline.months) && Number.isFinite(withExtra.months)
    ? baseline.months - withExtra.months : 0;
  const interestSaved = Number.isFinite(baseline.totalInterest) && Number.isFinite(withExtra.totalInterest)
    ? baseline.totalInterest - withExtra.totalInterest : 0;

  const fmtMonths = (m) => {
    if (!Number.isFinite(m)) return "—";
    const yrs = Math.floor(m / 12);
    const mo = m % 12;
    if (yrs === 0) return `${mo} mo`;
    if (mo === 0) return `${yrs} yr`;
    return `${yrs} yr ${mo} mo`;
  };

  // Smart slider max: cap at 50% of monthly payment, but at least BND 500.
  const sliderMax = Math.max(500, Math.round(loan.monthlyPayment * 0.5 / 10) * 10);

  return (
    <div className="mt-4 pt-4 border-t border-dashed border-[hsl(var(--border))]">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-6 h-6 rounded-md bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))] flex items-center justify-center">
          <I.Sparkles width="12" height="12"/>
        </div>
        <div className="text-[12px] font-semibold">What if I pay extra each month?</div>
      </div>

      <div className="grid md:grid-cols-[260px_1fr] gap-4">
        {/* Controls + outcomes */}
        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Extra /mo</label>
              <div className="text-sm font-bold tabular-nums">{window.fmtBND(extra)}</div>
            </div>
            <input
              type="range" min="0" max={sliderMax} step="10"
              value={extra}
              onChange={(e) => setExtra(Number(e.target.value))}
              className="w-full accent-[hsl(var(--primary))]"
            />
            <div className="flex justify-between text-[10px] text-[hsl(var(--muted-foreground))] tabular-nums mt-0.5">
              <span>0</span><span>{window.fmtBND(sliderMax)}</span>
            </div>
            <div className="flex gap-1 mt-2">
              {[50, 100, 200, 500].filter(v => v <= sliderMax).map(v => (
                <button key={v} type="button" onClick={() => setExtra(v)}
                  className={`flex-1 h-7 rounded-md text-[11px] font-semibold tabular-nums border transition-colors ${
                    extra === v ? "bg-[hsl(var(--primary))] text-white border-[hsl(var(--primary))]"
                                : "bg-white border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))]/40"}`}>
                  +{v}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-md bg-[hsl(var(--accent))]/40 border border-[hsl(var(--border))] p-2">
              <div className="text-[9px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Paid off in</div>
              <div className="text-sm font-bold tabular-nums mt-0.5">{fmtMonths(withExtra.months)}</div>
              {monthsSaved > 0 && <div className="text-[10px] font-semibold text-emerald-700 tabular-nums mt-0.5">−{fmtMonths(monthsSaved)} sooner</div>}
            </div>
            <div className="rounded-md bg-[hsl(var(--accent))]/40 border border-[hsl(var(--border))] p-2">
              <div className="text-[9px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Interest saved</div>
              <div className="text-sm font-bold tabular-nums mt-0.5 text-emerald-700">
                {interestSaved > 0 ? window.fmtBND(interestSaved) : window.fmtBND(0)}
              </div>
              <div className="text-[10px] text-[hsl(var(--muted-foreground))] tabular-nums mt-0.5">vs minimum-only</div>
            </div>
          </div>
        </div>

        {/* Chart */}
        <div>
          <div className="flex items-center gap-3 text-[10px] text-[hsl(var(--muted-foreground))] mb-1">
            <span className="inline-flex items-center gap-1">
              <span className="inline-block w-3 h-[2px] bg-rose-500" style={{ borderTop: "1px dashed hsl(0 70% 55%)" }}/>
              Minimum only
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="inline-block w-3 h-[2px] bg-[hsl(162_70%_35%)]"/>
              With +{window.fmtBND(extra)}
            </span>
          </div>
          <div className="rounded-md border border-[hsl(var(--border))] bg-white p-2">
            <PayoffChart baseline={baseline} withExtra={withExtra}/>
            <div className="flex justify-between text-[10px] text-[hsl(var(--muted-foreground))] tabular-nums mt-1 px-1">
              <span>Today</span>
              <span>Balance over time</span>
              <span>{fmtMonths(Math.max(baseline.months, withExtra.months))}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Debts = ({ onNav }) => {
  const I = window.Icons;
  const [debts, store] = window.useDebts();
  const blank = { name: "", lender: "", type: "Car", balance: "", rate: "", monthlyPayment: "" };
  const [draft, setDraft] = React.useState(blank);
  const [editingId, setEditingId] = React.useState(null);
  const [editDraft, setEditDraft] = React.useState({});

  const totalBalance = debts.reduce((s, d) => s + Number(d.balance || 0), 0);
  const totalMonthly = debts.reduce((s, d) => s + Number(d.monthlyPayment || 0), 0);
  const monthlyIncome = (window.duitplanData && window.duitplanData.summary && window.duitplanData.summary.monthlyNet) || 4200;
  const dti = monthlyIncome > 0 ? (totalMonthly / monthlyIncome) * 100 : 0;

  const TypeOptions = store.typeOptions();
  const Glyph = (name) => window.Icons[name] || window.Icons.Bank;

  const submit = (e) => {
    e.preventDefault();
    const balance = Number(draft.balance);
    const rate = Number(draft.rate);
    const monthlyPayment = Number(draft.monthlyPayment);
    if (!draft.name.trim() || !draft.lender.trim()) return;
    if (!Number.isFinite(balance) || balance < 0) return;
    if (!Number.isFinite(rate) || rate < 0) return;
    if (!Number.isFinite(monthlyPayment) || monthlyPayment < 0) return;
    store.add({
      name: draft.name.trim(), lender: draft.lender.trim(), type: draft.type,
      balance, rate, monthlyPayment,
    });
    setDraft(blank);
  };

  const startEdit = (d) => {
    setEditingId(d.id);
    setEditDraft({
      name: d.name, lender: d.lender, type: d.type || "Other",
      balance: String(d.balance), rate: String(d.rate), monthlyPayment: String(d.monthlyPayment),
    });
  };
  const saveEdit = () => {
    const balance = Number(editDraft.balance);
    const rate = Number(editDraft.rate);
    const monthlyPayment = Number(editDraft.monthlyPayment);
    if (!editDraft.name.trim() || !editDraft.lender.trim()) return;
    if (!Number.isFinite(balance) || balance < 0) return;
    if (!Number.isFinite(rate) || rate < 0) return;
    if (!Number.isFinite(monthlyPayment) || monthlyPayment < 0) return;
    store.update(editingId, {
      name: editDraft.name.trim(), lender: editDraft.lender.trim(), type: editDraft.type,
      balance, rate, monthlyPayment,
    });
    setEditingId(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Topbar
        title="Debts"
        subtitle="Add or edit loans. Each one becomes a Bank card on the Budgets page that you fund every month."
        actions={<Button variant="outline" size="sm" onClick={() => onNav && onNav("budgets")}>
          <I.Pie width="14" height="14"/>View on Budgets
        </Button>}
      />

      {/* Summary strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Total debt</div>
          <div className="text-2xl font-bold tabular-nums tracking-tight mt-1 text-rose-600">{window.fmtBND(totalBalance)}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">{debts.length} {debts.length === 1 ? "loan" : "loans"}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Monthly minimum</div>
          <div className="text-2xl font-bold tabular-nums tracking-tight mt-1">{window.fmtBND(totalMonthly)}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">Sum of minimum payments</div>
        </Card>
        <Card tinted className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Debt-to-income</div>
          <div className={`text-2xl font-bold tabular-nums tracking-tight mt-1 ${dti > 40 ? "text-rose-600" : dti > 30 ? "text-amber-700" : "text-[hsl(var(--primary))]"}`}>
            {dti.toFixed(0)}%
          </div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">{dti > 40 ? "High" : dti > 30 ? "Watch" : "Healthy"} · target &lt; 36%</div>
        </Card>
        <Card className="p-4 bg-[hsl(var(--accent))]/40 border-dashed">
          <div className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-md bg-white border border-[hsl(var(--border))] flex items-center justify-center text-[hsl(var(--primary))] shrink-0">
              <I.Lightbulb width="14" height="14"/>
            </div>
            <div className="flex-1">
              <div className="text-[12px] font-semibold">How this connects to Budgets</div>
              <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5 leading-relaxed">
                Each loan becomes a card in the <span className="font-semibold">Bank</span> column. The minimum payment is the monthly target you fund from your gaji.
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Add new */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-md bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))] flex items-center justify-center">
            <I.Plus width="14" height="14"/>
          </div>
          <h2 className="text-base font-semibold tracking-tight">Add a loan</h2>
        </div>
        <form onSubmit={submit} className="grid md:grid-cols-[1.4fr_1fr_120px_120px_120px_120px_auto] gap-2 items-end">
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Name</label>
            <input
              type="text" placeholder="e.g. Toyota Hilux loan"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              className="mt-1 w-full h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Lender</label>
            <input
              type="text" placeholder="BIBD, Baiduri…"
              value={draft.lender}
              onChange={(e) => setDraft({ ...draft, lender: e.target.value })}
              className="mt-1 w-full h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Type</label>
            <select
              value={draft.type}
              onChange={(e) => setDraft({ ...draft, type: e.target.value })}
              className="mt-1 w-full h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]">
              {TypeOptions.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Balance</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={draft.balance}
                onChange={(e) => setDraft({ ...draft, balance: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Rate</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <input
                type="number" min="0" step="0.1" placeholder="0.0"
                value={draft.rate}
                onChange={(e) => setDraft({ ...draft, rate: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] ml-1">%</span>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Min /mo</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={draft.monthlyPayment}
                onChange={(e) => setDraft({ ...draft, monthlyPayment: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
            </div>
          </div>
          <Button type="submit" size="default">
            <I.Plus width="14" height="14"/>Add
          </Button>
        </form>
      </Card>

      {/* List */}
      <Card className="p-0 overflow-hidden">
        <div className="px-5 py-3 flex items-center justify-between border-b border-[hsl(var(--border))]">
          <div className="text-sm font-semibold">Your loans</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))]">Tap a row to edit</div>
        </div>
        <div className="divide-y divide-[hsl(var(--border))]">
          {debts.length === 0 && (
            <div className="px-5 py-10 text-center text-sm text-[hsl(var(--muted-foreground))]">
              No loans yet. Add one above to start tracking debt repayment.
            </div>
          )}
          {debts.map(d => {
            const Ic = Glyph(store.iconFor(d.type));
            const isEditing = editingId === d.id;
            const pct = Math.round((d.progress || 0) * 100);
            return (
              <div key={d.id} className="px-5 py-4 hover:bg-[hsl(var(--accent))]/30 transition-colors">
                {isEditing ? (
                  <div className="grid md:grid-cols-[40px_1.4fr_1fr_120px_120px_120px_120px_auto_auto] gap-2 items-center">
                    <div className="w-9 h-9 rounded-md bg-rose-50 flex items-center justify-center text-rose-600">
                      <Ic width="16" height="16"/>
                    </div>
                    <input
                      type="text" value={editDraft.name}
                      onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })}
                      className="h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
                    <input
                      type="text" value={editDraft.lender}
                      onChange={(e) => setEditDraft({ ...editDraft, lender: e.target.value })}
                      className="h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
                    <select
                      value={editDraft.type}
                      onChange={(e) => setEditDraft({ ...editDraft, type: e.target.value })}
                      className="h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none">
                      {TypeOptions.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
                      <input type="number" min="0" step="0.01" value={editDraft.balance}
                        onChange={(e) => setEditDraft({ ...editDraft, balance: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                    </div>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <input type="number" min="0" step="0.1" value={editDraft.rate}
                        onChange={(e) => setEditDraft({ ...editDraft, rate: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] ml-1">%</span>
                    </div>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
                      <input type="number" min="0" step="0.01" value={editDraft.monthlyPayment}
                        onChange={(e) => setEditDraft({ ...editDraft, monthlyPayment: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                    </div>
                    <Button size="sm" onClick={saveEdit}><I.Check width="14" height="14"/>Save</Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                  </div>
                ) : (
                  <div>
                    <div className="grid grid-cols-[40px_1fr_auto_auto_auto] gap-3 items-center">
                      <div className="w-9 h-9 rounded-md bg-rose-50 text-rose-600 flex items-center justify-center">
                        <Ic width="16" height="16"/>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <div className="text-sm font-semibold truncate">{d.name}</div>
                          <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">{d.type}</span>
                        </div>
                        <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5 tabular-nums">
                          {d.lender} · {d.rate}% APR · {window.fmtBND(d.balance)} remaining
                        </div>
                        {/* Lifetime progress bar */}
                        <div className="mt-2 h-1.5 rounded-full bg-[hsl(var(--muted))] overflow-hidden max-w-md">
                          <div className="h-full rounded-full bg-rose-500" style={{ width: `${pct}%` }}/>
                        </div>
                        <div className="text-[10px] text-[hsl(var(--muted-foreground))] mt-1 tabular-nums">{pct}% paid off over the loan's lifetime</div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Min /mo</div>
                        <div className="text-sm font-bold tabular-nums">{window.fmtBND(d.monthlyPayment)}</div>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => startEdit(d)}>
                        <I.Edit width="13" height="13"/>Edit
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => {
                        if (confirm(`Delete "${d.name}"? Its card will also be removed from Budgets.`)) {
                          store.remove(d.id);
                        }
                      }} className="text-rose-600 hover:bg-rose-50">
                        <I.Trash width="13" height="13"/>
                      </Button>
                    </div>
                    <LoanSimulation loan={d}/>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};

window.Debts = Debts;
