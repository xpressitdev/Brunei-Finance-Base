// Expense Categories — manage the list of envelopes used on the Budgets page.
// Adding/editing here flows directly into Budgets via window.categoriesStore.

const ExpenseCategories = ({ onNav }) => {
  const I = window.Icons;
  const [categories, store] = window.useCategories();
  const [draft, setDraft] = React.useState({ name: "", icon: "Receipt", fixed: false, defaultBudget: "" });
  const [editingId, setEditingId] = React.useState(null);
  const [editDraft, setEditDraft] = React.useState({});

  const totalBudget = categories.reduce((s, c) => s + Number(c.defaultBudget || 0), 0);
  const fixedCount = categories.filter(c => c.fixed).length;

  const submit = (e) => {
    e.preventDefault();
    const name = draft.name.trim();
    const budget = Number(draft.defaultBudget);
    if (!name || !Number.isFinite(budget) || budget < 0) return;
    store.add({ name, icon: draft.icon, fixed: draft.fixed, defaultBudget: budget });
    setDraft({ name: "", icon: "Receipt", fixed: false, defaultBudget: "" });
  };

  const startEdit = (c) => {
    setEditingId(c.id);
    setEditDraft({ name: c.name, icon: c.icon, fixed: c.fixed, defaultBudget: String(c.defaultBudget) });
  };
  const saveEdit = () => {
    const budget = Number(editDraft.defaultBudget);
    if (!editDraft.name.trim() || !Number.isFinite(budget) || budget < 0) return;
    store.update(editingId, { name: editDraft.name.trim(), icon: editDraft.icon, fixed: editDraft.fixed, defaultBudget: budget });
    setEditingId(null);
  };

  const IconList = store.iconOptions();
  const Glyph = (name) => I[name] || I.Receipt;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Topbar
        title="Expense Categories"
        subtitle="Add or edit categories. Each one becomes an envelope on the Budgets page."
        actions={<Button variant="outline" size="sm" onClick={() => onNav && onNav("budgets")}>
          <I.Pie width="14" height="14"/>View on Budgets
        </Button>}
      />

      {/* Summary strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Categories</div>
          <div className="text-2xl font-bold tracking-tight mt-1">{categories.length}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">{fixedCount} fixed · {categories.length - fixedCount} flexible</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Total monthly budget</div>
          <div className="text-2xl font-bold tracking-tight mt-1 text-[hsl(var(--primary))]">{window.fmtBND(totalBudget)}</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-1">Across all envelopes</div>
        </Card>
        <Card className="p-4 md:col-span-2 bg-[hsl(var(--accent))]/40 border-dashed">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-md bg-white border border-[hsl(var(--border))] flex items-center justify-center text-[hsl(var(--primary))]">
              <I.Lightbulb width="16" height="16"/>
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold">How this connects to Budgets</div>
              <div className="text-[12px] text-[hsl(var(--muted-foreground))] mt-0.5 leading-relaxed">
                Every category you add appears as a draggable envelope on the Budgets tab, starting at <span className="font-semibold">BND 0</span>. You fund it by dragging chips from the money bag — fixed and flexible categories work the same way. The <span className="font-semibold">Fixed</span> tag is just a visual reminder for unavoidable monthly costs (rent, utilities) so you fund them first; the <span className="font-semibold">default budget</span> you set here is the suggested target shown on the envelope.
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Add new */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-md bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))] flex items-center justify-center">
            <I.Plus width="14" height="14"/>
          </div>
          <h2 className="text-base font-semibold tracking-tight">Add a category</h2>
        </div>
        <form onSubmit={submit} className="grid md:grid-cols-[1fr_140px_140px_120px_auto] gap-2 items-end">
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Name</label>
            <input
              type="text" placeholder="e.g. Coffee, Petrol, Subscriptions"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              className="mt-1 w-full h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Icon</label>
            <div className="mt-1 flex flex-wrap gap-1 max-h-9 overflow-hidden">
              <select
                value={draft.icon}
                onChange={(e) => setDraft({ ...draft, icon: e.target.value })}
                className="h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))] w-full">
                {IconList.map(name => <option key={name} value={name}>{name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Default budget</label>
            <div className="mt-1 flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
              <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={draft.defaultBudget}
                onChange={(e) => setDraft({ ...draft, defaultBudget: e.target.value })}
                className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Type</label>
            <button
              type="button"
              onClick={() => setDraft({ ...draft, fixed: !draft.fixed })}
              className={`mt-1 w-full h-9 px-3 rounded-md border text-sm font-semibold transition-colors ${
                draft.fixed
                  ? "bg-orange-50 border-orange-300 text-orange-800"
                  : "bg-white border-[hsl(var(--border))] text-[hsl(var(--foreground))]"}`}>
              {draft.fixed ? "Fixed" : "Flexible"}
            </button>
          </div>
          <Button type="submit" size="default">
            <I.Plus width="14" height="14"/>Add
          </Button>
        </form>
      </Card>

      {/* List */}
      <Card className="p-0 overflow-hidden">
        <div className="px-5 py-3 flex items-center justify-between border-b border-[hsl(var(--border))]">
          <div className="text-sm font-semibold">Your categories</div>
          <div className="text-[11px] text-[hsl(var(--muted-foreground))]">Tap a row to edit</div>
        </div>
        <div className="divide-y divide-[hsl(var(--border))]">
          {categories.length === 0 && (
            <div className="px-5 py-8 text-center text-sm text-[hsl(var(--muted-foreground))]">
              No categories yet. Add one above to start budgeting.
            </div>
          )}
          {categories.map(c => {
            const Ic = Glyph(c.icon);
            const isEditing = editingId === c.id;
            const overspent = c.spent > c.defaultBudget;
            return (
              <div key={c.id} className="px-5 py-3 hover:bg-[hsl(var(--accent))]/30 transition-colors">
                {isEditing ? (
                  <div className="grid md:grid-cols-[40px_1fr_140px_140px_120px_auto_auto] gap-2 items-center">
                    <div className="w-9 h-9 rounded-md bg-[hsl(var(--accent))]/50 flex items-center justify-center text-[hsl(var(--foreground))]">
                      <Ic width="16" height="16"/>
                    </div>
                    <input
                      type="text"
                      value={editDraft.name}
                      onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })}
                      className="h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none focus:border-[hsl(var(--primary))]"/>
                    <select
                      value={editDraft.icon}
                      onChange={(e) => setEditDraft({ ...editDraft, icon: e.target.value })}
                      className="h-9 px-2 rounded-md border border-[hsl(var(--border))] bg-white text-sm outline-none">
                      {IconList.map(n => <option key={n} value={n}>{n}</option>)}
                    </select>
                    <div className="flex items-center h-9 px-3 rounded-md border border-[hsl(var(--border))] bg-white">
                      <span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))] mr-1">BND</span>
                      <input
                        type="number" min="0" step="0.01"
                        value={editDraft.defaultBudget}
                        onChange={(e) => setEditDraft({ ...editDraft, defaultBudget: e.target.value })}
                        className="flex-1 bg-transparent text-sm font-bold tabular-nums outline-none w-full"/>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEditDraft({ ...editDraft, fixed: !editDraft.fixed })}
                      className={`h-9 px-3 rounded-md border text-sm font-semibold ${
                        editDraft.fixed
                          ? "bg-orange-50 border-orange-300 text-orange-800"
                          : "bg-white border-[hsl(var(--border))]"}`}>
                      {editDraft.fixed ? "Fixed" : "Flexible"}
                    </button>
                    <Button size="sm" onClick={saveEdit}><I.Check width="14" height="14"/>Save</Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-[40px_1fr_auto_auto_auto] gap-3 items-center">
                    <div className={`w-9 h-9 rounded-md flex items-center justify-center ${
                      c.fixed ? "bg-orange-50 text-orange-700" : "bg-[hsl(162_70%_35%/.08)] text-[hsl(var(--primary))]"}`}>
                      <Ic width="16" height="16"/>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-semibold truncate">{c.name}</div>
                        {c.fixed && <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-orange-50 text-orange-700 border border-orange-200">Fixed</span>}
                      </div>
                      <div className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5">
                        {window.fmtBND(c.spent || 0)} spent this month
                        {overspent && <span className="ml-2 text-rose-600 font-semibold">over budget</span>}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] uppercase tracking-wider font-semibold text-[hsl(var(--muted-foreground))]">Budget</div>
                      <div className="text-sm font-bold tabular-nums">{window.fmtBND(c.defaultBudget)}</div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => startEdit(c)}>
                      <I.Edit width="13" height="13"/>Edit
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => {
                      if (confirm(`Delete "${c.name}"? Its envelope will also be removed from Budgets.`)) {
                        store.remove(c.id);
                      }
                    }} className="text-rose-600 hover:bg-rose-50">
                      <I.Trash width="13" height="13"/>
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};

window.ExpenseCategories = ExpenseCategories;
