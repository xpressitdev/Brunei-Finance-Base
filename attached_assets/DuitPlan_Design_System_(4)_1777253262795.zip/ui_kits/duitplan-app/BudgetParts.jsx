// Helpers used by Budgets.jsx — money bag, chips, bucket columns, envelope cards, modal.

const MoneyChip = ({ amount, disabled, onDragStart, onDragEnd, metaphor, animationLevel }) => {
  if (metaphor !== "drag") return null;
  const motion = animationLevel === "satisfying" ? "hover:-translate-y-1 active:scale-95 hover:rotate-[-2deg]" : "hover:-translate-y-0.5";
  return (
    <div draggable={!disabled} onDragStart={disabled ? undefined : onDragStart} onDragEnd={onDragEnd}
      aria-disabled={disabled}
      className={`select-none ${disabled ? "cursor-not-allowed opacity-40" : "cursor-grab active:cursor-grabbing"}
        rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800
        px-3 py-2 text-sm font-bold tabular-nums shadow-sm
        transition-all duration-150 ${disabled ? "" : motion}`}>
      BND {amount}
    </div>
  );
};

// Custom-amount chip — type any number, then drag the chip to a bucket.
// The chip becomes draggable as soon as the value parses to a positive number
// that's <= currently available. Vault drops still trigger the unlock modal upstream.
const CustomMoneyChip = ({ available, value, onChange, onDragStart, onDragEnd, animationLevel }) => {
  const num = Number(value);
  const valid = Number.isFinite(num) && num > 0;
  const disabled = !valid || num > available;
  const motion = animationLevel === "satisfying" ? "hover:-translate-y-1 active:scale-95 hover:rotate-[-2deg]" : "hover:-translate-y-0.5";
  const tooMuch = valid && num > available;

  return (
    <div
      draggable={!disabled}
      onDragStart={disabled ? undefined : (e) => onDragStart(num)(e)}
      onDragEnd={onDragEnd}
      aria-disabled={disabled}
      title={tooMuch ? `Only BND ${available.toFixed(2)} left in the bag` : valid ? `Drag BND ${num} onto a bucket` : "Type any amount, then drag"}
      className={`col-span-3 flex items-center gap-1 select-none rounded-md border px-2 py-1.5 transition-all duration-150
        ${disabled
          ? (tooMuch
              ? "border-rose-200 bg-rose-50/60 text-rose-700 cursor-not-allowed"
              : "border-dashed border-emerald-300 bg-white/60 text-emerald-700/80 cursor-text")
          : `border-emerald-300 bg-emerald-100 text-emerald-900 cursor-grab active:cursor-grabbing shadow-sm ${motion}`}`}>
      <span className="text-[11px] font-bold tracking-wide shrink-0">BND</span>
      <input
        type="number" inputMode="decimal" min="0" step="0.01"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
        placeholder="custom"
        className="w-full bg-transparent outline-none text-sm font-bold tabular-nums placeholder:text-emerald-700/40 placeholder:font-medium"
        // Stop drag-from-input so users can edit; the chip itself is the drag handle (the wrapper).
        draggable={false}
        onDragStart={(e) => e.stopPropagation()}
      />
      {valid && !tooMuch && (
        <span className="text-[10px] font-semibold uppercase tracking-wider opacity-60 shrink-0">drag →</span>
      )}
    </div>
  );
};

// Interactive bag of money — full when there's available to allocate, empty when not.
// Drag amounts OUT of the bag (chips around it), and drop chips/allocations BACK INTO it
// to deallocate. Visualised with a coin "fill" inside an SVG bag silhouette.
const MoneyBag = ({ available, total, onDropBack, isOver, onDragOver, onDragLeave, animationLevel, motionMS }) => {
  const I = window.Icons;
  const pct = Math.max(0, Math.min(1, total > 0 ? available / total : 0));
  const empty = available <= 0;
  // The fill rises with how full the bag is — clipped by the bag silhouette.
  const fillY = 100 - pct * 78; // top of fill in viewBox 0..100; bag interior roughly y=18..96
  const wobble = animationLevel === "satisfying" ? "wave-anim" : "";
  const transition = `all ${motionMS}ms cubic-bezier(.2,.8,.2,1)`;

  return (
    <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDropBack}
         className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed
                    ${isOver ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary)/.05)]"
                             : empty ? "border-rose-200 bg-rose-50/40"
                             : "border-[hsl(var(--card-border))] bg-[hsl(var(--accent))]/40"}
                    px-4 py-3 w-44 select-none`}
         style={{ transition }}
         title="Drag chips back here to deallocate">
      <svg viewBox="0 0 100 110" className="w-24 h-28" aria-hidden>
        <defs>
          <clipPath id="bagClip">
            {/* Bag interior silhouette */}
            <path d="M30 22 L70 22 L88 50 C92 78 78 100 50 100 C22 100 8 78 12 50 Z"/>
          </clipPath>
          <linearGradient id="coinGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFD668"/>
            <stop offset="100%" stopColor="#E5A23B"/>
          </linearGradient>
        </defs>
        {/* String/tie */}
        <path d="M28 22 Q50 6 72 22" stroke="#9A6B3F" strokeWidth="3" fill="none" strokeLinecap="round"/>
        <circle cx="50" cy="14" r="2.5" fill="#9A6B3F"/>
        {/* Bag body */}
        <path d="M30 22 L70 22 L88 50 C92 78 78 100 50 100 C22 100 8 78 12 50 Z"
              fill={empty ? "#F5E1CC" : "#E8C9A2"} stroke="#9A6B3F" strokeWidth="2.5" strokeLinejoin="round"/>
        {/* Coin fill, clipped */}
        <g clipPath="url(#bagClip)">
          <rect x="0" y={fillY} width="100" height="120" fill="url(#coinGrad)"
                style={{ transition: `y ${motionMS}ms cubic-bezier(.2,.8,.2,1)` }}/>
          {/* Top wave on the fill surface */}
          {!empty && (
            <path className={wobble}
                  d={`M-5 ${fillY + 3} Q 25 ${fillY - 1} 50 ${fillY + 3} T 105 ${fillY + 3} L 105 110 L -5 110 Z`}
                  fill="#FFD668" opacity="0.7"/>
          )}
          {/* Coin glints */}
          {!empty && pct > 0.15 && (
            <>
              <circle cx="38" cy={fillY + 14} r="2.5" fill="#FFF2C2" opacity="0.7"/>
              <circle cx="58" cy={fillY + 22} r="2"   fill="#FFF2C2" opacity="0.6"/>
              <circle cx="48" cy={fillY + 34} r="2.5" fill="#FFF2C2" opacity="0.5"/>
            </>
          )}
        </g>
        {/* Currency mark on the bag */}
        <text x="50" y="62" textAnchor="middle" fontSize="22" fontWeight="800"
              fill={empty ? "#B97947" : "#9A6B3F"} fontFamily="Inter, sans-serif"
              opacity={empty ? 0.7 : 0.35}>$</text>
      </svg>
      <div className="text-center mt-1">
        <div className={`text-[10px] uppercase tracking-wider font-semibold ${empty ? "text-rose-600" : "text-[hsl(var(--muted-foreground))]"}`}>
          {empty ? "Bag is empty" : "In the bag"}
        </div>
        <div className={`text-base font-bold tabular-nums ${empty ? "text-rose-600" : "text-[hsl(var(--foreground))]"}`}>
          {window.fmtBND(Math.max(0, available))}
        </div>
      </div>
      {isOver && (
        <div className="absolute inset-0 rounded-2xl bg-[hsl(var(--primary)/.06)] flex items-center justify-center pointer-events-none">
          <div className="bg-white px-2 py-1 rounded-md border border-[hsl(var(--primary))] text-[11px] font-semibold text-[hsl(var(--primary))]">
            <I.Plus width="11" height="11" className="inline -mt-0.5"/> drop to deallocate
          </div>
        </div>
      )}
      <style>{`
        @keyframes coinWave { 0%,100% { transform: translateX(0); } 50% { transform: translateX(-4px); } }
        .wave-anim { animation: coinWave 3.2s ease-in-out infinite; }
      `}</style>
    </div>
  );
};

const BucketColumn = ({ title, subtitle, illo, iconBg, iconColor, children, count, total }) => {
  const I = window.Icons;
  const storageKey = `duitplan-budget-col-collapsed:${title}`;
  const [collapsed, setCollapsed] = React.useState(() => {
    try { return localStorage.getItem(storageKey) === "1"; } catch { return false; }
  });
  React.useEffect(() => {
    try { localStorage.setItem(storageKey, collapsed ? "1" : "0"); } catch {}
  }, [collapsed, storageKey]);

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={() => setCollapsed(c => !c)}
        aria-expanded={!collapsed}
        className="w-full flex items-center gap-3 px-1 group text-left">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${iconBg}`}>
          <img src={`../../assets/illustration-${illo}.png`} className="w-7 h-7 object-contain" alt=""/>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <div className="text-base font-semibold tracking-tight truncate">{title}</div>
            {typeof count === "number" && (
              <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] tabular-nums">
                {count}
              </span>
            )}
          </div>
          <div className="text-xs text-[hsl(var(--muted-foreground))] truncate">
            {collapsed && typeof total === "number"
              ? <>{window.fmtBND(total)} allocated · click to expand</>
              : subtitle}
          </div>
        </div>
        <div className={`w-7 h-7 rounded-md flex items-center justify-center text-[hsl(var(--muted-foreground))] group-hover:bg-[hsl(var(--accent))]/50 transition-transform ${collapsed ? "" : "rotate-180"}`}>
          <I.Chevron width="14" height="14"/>
        </div>
      </button>
      {!collapsed && <div className="space-y-2 animate-in fade-in duration-200">{children}</div>}
    </div>
  );
};

const Envelope = ({ bucket: b, kind, isOver, pulse, isVault, metaphor, envelopeStyle, motionMS,
                   onDragOver, onDragLeave, onDrop, onDragChip, onSlider, onInput, onLogSpend, onGotoDebts, available }) => {
  const I = window.Icons;
  // For envelopes: REMAINING vs allocated (bar depletes as transactions hit the category — low bar = low envelope).
  // For vaults: saved vs target (fills toward goal).
  // For loans: BAR SHOWS LIFETIME REPAYMENT PROGRESS (e.g. 1/4 of the way through the loan).
  //   Allocating extra this month (b.allocated > b.target/min payment) shortens the loan —
  //   we surface that as a "shortened by N months" hint that ties to the Debts simulation.
  const isEnvelope = kind === "envelope";
  const isLoan = kind === "loans";
  const remaining = isEnvelope ? b.allocated - b.spent : null;
  const overspent = isEnvelope && b.spent > b.allocated;

  let pct;
  if (isEnvelope) {
    pct = overspent ? 0 : Math.max(0, (remaining / Math.max(b.allocated, 1)) * 100);
  } else if (isVault) {
    pct = Math.min(100, ((b.saved + b.allocated) / Math.max(b.target, 1)) * 100);
  } else if (isLoan) {
    // For loans the bar shows this-month payment vs the minimum due (target).
    // 100% on the bar = minimum repayment met; beyond 100% renders as a green "extra" segment.
    pct = Math.min(100, (b.allocated / Math.max(b.target, 1)) * 100);
  } else {
    pct = Math.min(100, (b.allocated / Math.max(b.target, 1)) * 100);
  }
  const isFunded = !isEnvelope && !isLoan && b.target && b.allocated >= b.target;
  // Extra contribution this month above the minimum monthly payment.
  const extra = isLoan ? Math.max(0, b.allocated - (b.target || 0)) : 0;
  // Rough simulation: BND 100 extra ≈ ~2 months saved on the loan tail. Tunable.
  const monthsSaved = isLoan && extra > 0 ? Math.max(1, Math.round(extra / 50)) : 0;

  // Envelope fill colour shifts as it depletes — primary while healthy,
  // amber when getting low, rose when nearly empty or overspent.
  const envFill = overspent ? "bg-rose-500"
                : pct <= 10  ? "bg-rose-500"
                : pct <= 25  ? "bg-amber-500"
                : "bg-[hsl(var(--primary))]";
  const fillColor = isEnvelope ? envFill
                  : isVault    ? "bg-amber-400"
                  : kind === "loans" ? "bg-rose-400"
                  : "bg-[hsl(var(--primary))]";

  const borderState = overspent ? "border-rose-400"
                    : isOver ? "border-[hsl(var(--primary))] ring-2 ring-[hsl(var(--primary)/.25)]"
                    : "border-[hsl(var(--card-border))]";

  const Glyph = I[b.icon] || I.Wallet;
  const showIllo = envelopeStyle === "illustration";
  const showGlyph = envelopeStyle === "glyph";

  const transition = `all ${motionMS}ms cubic-bezier(.2,.8,.2,1)`;

  return (
    <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}
         className={`relative bg-white rounded-xl border ${borderState}
                    ${pulse ? "scale-[1.015]" : "scale-100"}
                    p-4 shadow-[var(--shadow-sm)]`}
         style={{ transition }}>
      {pulse && (
        <div className="absolute inset-0 rounded-xl bg-[hsl(var(--primary)/.08)] pointer-events-none animate-pulse"/>
      )}

      <div className="flex items-start gap-3">
        {showIllo && (
          <img src={`../../assets/illustration-${b.illo}.png`} className="w-9 h-9 object-contain shrink-0" alt=""/>
        )}
        {showGlyph && (
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0
            ${isVault ? "bg-amber-50 text-amber-700" : kind === "loans" ? "bg-rose-50 text-rose-600" : "bg-[hsl(162_70%_35%/.08)] text-[hsl(var(--primary))]"}`}>
            <Glyph width="18" height="18"/>
          </div>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="text-sm font-semibold truncate">{b.name}</div>
            {b.fixed && <Badge variant="outline" className="text-[10px] py-0">fixed</Badge>}
            {b.auto && <Badge variant="outline" className="text-[10px] py-0">auto</Badge>}
            {isFunded && <Badge variant="success" className="text-[10px] py-0"><I.Check width="10" height="10"/>funded</Badge>}
            {overspent && <Badge variant="rose" className="text-[10px] py-0">over</Badge>}
          </div>

          <div className="flex items-baseline justify-between mt-0.5 gap-2">
            {/* Big number = how much you're paying THIS MONTH (loans) / left in envelope / saved in vault. */}
            <div className={`text-lg font-bold tabular-nums ${isEnvelope && overspent ? "text-rose-600" : ""}`}>
              {isEnvelope ? window.fmtBND(Math.max(0, remaining))
                : isVault ? window.fmtBND((b.saved || 0) + b.allocated)
                : isLoan  ? window.fmtBND(b.allocated || 0)
                : window.fmtBND(b.allocated)}
            </div>
            {isEnvelope && (
              <div className={`text-xs tabular-nums text-right ${overspent ? "text-rose-600 font-semibold" : "text-[hsl(var(--muted-foreground))]"}`}>
                {overspent ? `${window.fmtBND(b.spent - b.allocated)} over` : `left of ${window.fmtBND(b.allocated)}`}
              </div>
            )}
            {isLoan && (
              <div className="text-xs text-[hsl(var(--muted-foreground))] tabular-nums text-right">
                <div>this month</div>
                <div>{window.fmtBND(b.balance || 0)} owed</div>
              </div>
            )}
            {isVault && b.target && (
              <div className="text-xs text-[hsl(var(--muted-foreground))] tabular-nums text-right">
                of {window.fmtBND(b.target)} goal
              </div>
            )}
          </div>

          {isLoan ? (() => {
            // Two-zone bar: rose track (this month vs minimum), green overflow once minimum is met.
            // The rose fill is capped at 50% of bar width — the indicator tick sits at that 50% mark.
            // The green overflow extends from the tick toward the right edge, sized by extra/min ratio.
            const minPct = Math.min(100, pct); // 0–100 of minimum
            const minHalf = (minPct / 100) * 50; // 0–50% of bar width
            const overRatio = b.target > 0 ? extra / b.target : 0; // 0..1+
            const overHalf = Math.min(50, overRatio * 50);          // 0–50% of bar width
            return (
              <div className="relative h-2 rounded-full mt-2 overflow-hidden bg-[hsl(var(--muted))]">
                {/* base repayment fill (rose) */}
                <div className="absolute inset-y-0 left-0 bg-rose-400 rounded-l-full"
                     style={{ width: `${minHalf}%`, transition }}/>
                {/* extra-this-month overflow (green) starting at the tick */}
                {overHalf > 0 && (
                  <div className="absolute inset-y-0 bg-emerald-500"
                       style={{ left: "50%", width: `${overHalf}%`, transition }}/>
                )}
                {/* minimum-payment indicator tick */}
                <div className="absolute inset-y-[-2px] w-[2px] bg-[hsl(var(--foreground))]"
                     style={{ left: "calc(50% - 1px)" }}
                     title="Minimum payment"/>
              </div>
            );
          })() : (
            <div className={`relative h-1.5 rounded-full mt-2 overflow-hidden
                            ${overspent ? "bg-rose-100" : "bg-[hsl(var(--muted))]"}`}>
              <div className={`h-full rounded-full ${fillColor}`}
                   style={{ width: `${pct}%`, transition }}/>
            </div>
          )}
          {isEnvelope && b.spent > 0 && (
            <div className="text-[10px] text-[hsl(var(--muted-foreground))] mt-1 tabular-nums">
              {overspent
                ? <span className="text-rose-600 font-semibold">{window.fmtBND(b.spent - b.allocated)} over · envelope empty</span>
                : <>{window.fmtBND(remaining)} remaining of {window.fmtBND(b.allocated)} allocated</>}
            </div>
          )}
          {isLoan && (
            <div className="text-[10px] text-[hsl(var(--muted-foreground))] mt-1 tabular-nums flex items-center justify-between gap-2">
              <span>min {window.fmtBND(b.target || 0)}/mo · paying {window.fmtBND(b.allocated)}</span>
              {monthsSaved > 0
                ? <span className="text-emerald-700 font-semibold">−{monthsSaved} mo on tail</span>
                : <span className="text-[hsl(var(--muted-foreground))]">add to shorten loan</span>}
            </div>
          )}

          {/* Metaphor controls */}
          {metaphor === "slider" && (
            <input type="range" min="0" max={Math.max(b.target || 1500, b.allocated)} step="10"
              value={b.allocated} onChange={(e) => onSlider(Number(e.target.value))}
              className="w-full mt-3 accent-[hsl(var(--primary))]"/>
          )}
          {metaphor === "input" && (
            <div className="flex items-center gap-2 mt-3">
              <span className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">BND</span>
              <input type="number" value={b.allocated} min="0" step="10"
                onChange={(e) => onInput(Number(e.target.value))}
                className="flex-1 h-8 px-2 rounded-md border border-[hsl(var(--input))] text-sm tabular-nums outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"/>
              <button onClick={() => onInput(b.allocated + 50)}
                className="h-8 px-2 rounded-md bg-[hsl(var(--accent))] text-xs font-semibold">+50</button>
            </div>
          )}
          {metaphor === "drag" && b.allocated >= 50 && !b.auto && !b.fixed && (
            <button draggable onDragStart={(e) => onDragChip(50)(e)}
              className="mt-2 text-[11px] font-semibold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] cursor-grab active:cursor-grabbing inline-flex items-center gap-1">
              <I.Activity width="11" height="11"/> drag −50 elsewhere
            </button>
          )}
          {/* Spending is driven by real transactions on the Transactions page \u2014 the bar drains from there, never from a button here. */}
          {isLoan && onGotoDebts && (
            <button onClick={onGotoDebts}
              className="mt-3 w-full text-[11px] font-semibold text-rose-700 hover:text-rose-800 inline-flex items-center justify-center gap-1
                         h-7 rounded-md border border-rose-200 bg-rose-50/60 hover:bg-rose-50">
              Manage in Debts <I.Arrow width="11" height="11"/>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const EmptyHint = ({ children }) => (
  <div className="rounded-xl border border-dashed border-[hsl(var(--card-border))] p-6 text-center text-xs text-[hsl(var(--muted-foreground))]">
    {children}
  </div>
);

const Modal = ({ onClose, children }) => (
  <div className="fixed inset-0 z-40 flex items-center justify-center p-4 animate-in fade-in" style={{background: "rgba(0,0,0,.40)"}}>
    <div className="bg-white rounded-xl border border-[hsl(var(--card-border))] shadow-xl max-w-lg w-full p-6"
         onClick={(e) => e.stopPropagation()}>
      {children}
    </div>
  </div>
);

Object.assign(window, { MoneyChip, CustomMoneyChip, MoneyBag, BucketColumn, Envelope, EmptyHint, Modal });
